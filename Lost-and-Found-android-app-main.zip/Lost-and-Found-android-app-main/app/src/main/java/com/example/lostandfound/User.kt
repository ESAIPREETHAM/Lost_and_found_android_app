package com.example.lostandfound

data class User(val fullName: String? = null, val rollNumber: String? = null, val email: String? = null, val phoneNumber: String? = null, val profileImageUrl: String? = null, val uid: String? = null)

